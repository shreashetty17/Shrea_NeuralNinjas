import React from 'react';

export const KaamWalaLogo = ({ size = 'md', isWhite = false, onClick }) => {
  const isSmall = size === 'sm';
  const isLarge = size === 'lg';

  const iconSize = isSmall ? 'w-8 h-8' : isLarge ? 'w-12 h-12' : 'w-10 h-10';
  const textSize = isSmall ? 'text-xl' : isLarge ? 'text-3xl sm:text-4xl' : 'text-2xl';

  return (
    <div 
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 select-none ${onClick ? 'cursor-pointer group' : ''}`}
    >
      {/* Aesthetic Geometric Emblem */}
      <div className={`relative ${iconSize} rounded-2xl bg-gradient-to-br from-teal-500 via-teal-600 to-teal-800 p-0.5 shadow-md shadow-teal-700/20 flex items-center justify-center transition-transform ${onClick ? 'group-hover:scale-105' : ''}`}>
        {/* Sleek SVG Brand Glyph */}
        <svg 
          viewBox="0 0 36 36" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full p-1.5"
        >
          {/* Subtle geometric grid background */}
          <rect width="36" height="36" rx="10" fill="url(#brandGradient)" />
          
          {/* Stylized K + Arch / Bridge motif representing Kaam + Setu / Wala */}
          <path 
            d="M11 9V27M11 18H16L24 9M16 18L25 27" 
            stroke="white" 
            strokeWidth="3.2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
          />
          {/* Energetic Saffron Orange Spark Dot */}
          <circle cx="26" cy="10" r="3" fill="#ea580c" stroke="white" strokeWidth="1.5" />
          
          <defs>
            <linearGradient id="brandGradient" x1="0" y1="0" x2="36" y2="36" gradientUnits="userSpaceOnUse">
              <stop stopColor="#0d9488" />
              <stop offset="1" stopColor="#0f766e" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Clean Aesthetic Wordmark: KaamWala (No subtitles) */}
      <div className="flex items-baseline">
        <span className={`font-display font-bold tracking-tight leading-none ${textSize} ${isWhite ? 'text-white' : 'text-slate-900'}`}>
          Kaam<span className="text-secondary-600">Wala</span>
        </span>
        <span className="w-1.5 h-1.5 rounded-full bg-secondary-600 ml-1 self-baseline" />
      </div>
    </div>
  );
};
