import React from 'react';
import { 
  Send, 
  Users, 
  ArrowLeftRight, 
  ShieldCheck, 
  CheckCircle2, 
  XCircle,
  Clock,
  Mic,
  Zap,
  ArrowRight
} from 'lucide-react';

export const CustomerHowItWorks = ({ onStartBooking }) => {
  return (
    <div className="space-y-16 animate-in fade-in">
      
      {/* Page Header */}
      <div className="space-y-4 max-w-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-100 text-primary-800 text-xs font-bold uppercase tracking-wider">
          <span>How It Works</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-display font-bold text-slate-900 tracking-tight">
          Fair pricing through direct reverse auction
        </h1>
        <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
          No fixed prices. No middleman taking a 35% cut. You set your budget, verified workers bid, you negotiate, and work is completed in 30 minutes.
        </p>
      </div>

      {/* 4 Interactive Process Steps */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        <div className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-4 relative overflow-hidden">
          <div className="w-12 h-12 rounded-2xl bg-primary-50 text-primary-700 font-display font-bold text-base flex items-center justify-center">
            01
          </div>
          <h3 className="text-lg font-display font-bold text-slate-900">
            Post your request
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Tell us what is broken (e.g. leaking faucet diverter) and specify your target budget range (e.g. ₹250–₹450). Add a photo or voice note.
          </p>
          <div className="text-[11px] font-bold text-primary-600 bg-primary-50 p-2.5 rounded-xl border border-primary-100">
            Broadcasting to 30+ workers within 3 km
          </div>
        </div>

        <div className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-4 relative overflow-hidden">
          <div className="w-12 h-12 rounded-2xl bg-primary-50 text-primary-700 font-display font-bold text-base flex items-center justify-center">
            02
          </div>
          <h3 className="text-lg font-display font-bold text-slate-900">
            Workers bid directly
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Available pros review your job and submit live quotes. You see their photo, customer rating, distance, experience, and estimated arrival time.
          </p>
          <div className="text-[11px] font-bold text-emerald-800 bg-emerald-50 p-2.5 rounded-xl border border-emerald-100">
            Quotes arrive within 30–60 seconds
          </div>
        </div>

        <div className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-4 relative overflow-hidden">
          <div className="w-12 h-12 rounded-2xl bg-primary-50 text-primary-700 font-display font-bold text-base flex items-center justify-center">
            03
          </div>
          <h3 className="text-lg font-display font-bold text-slate-900">
            Negotiate & accept
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            You can send a counteroffer (e.g. counter ₹350 with ₹320). When accepted, the funds are safely locked into Escrow-Lite protection.
          </p>
          <div className="text-[11px] font-bold text-secondary-800 bg-secondary-50 p-2.5 rounded-xl border border-secondary-100">
            100% worker-set pricing • Zero commission
          </div>
        </div>

        <div className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-4 relative overflow-hidden">
          <div className="w-12 h-12 rounded-2xl bg-primary-50 text-primary-700 font-display font-bold text-base flex items-center justify-center">
            04
          </div>
          <h3 className="text-lg font-display font-bold text-slate-900">
            Track, chat & verify
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Track the worker's bike on the live map. Chat in real-time. Share your 4-digit OTP upon arrival. Release payment only when satisfied.
          </p>
          <div className="text-[11px] font-bold text-slate-700 bg-slate-100 p-2.5 rounded-xl border border-slate-200">
            Arrives in 15–30 mins with Start OTP 4829
          </div>
        </div>

      </div>

      {/* The KaamWala Difference vs Fixed Monopoly Apps */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-8 sm:p-12 shadow-bolt-md space-y-8">
        <div>
          <span className="text-[11px] font-black uppercase tracking-widest text-secondary-600">
            THE KAAMWALA DIFFERENCE
          </span>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 mt-1">
            Why fixed pricing is broken
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Comparing KaamWala's open marketplace against monopolistic fixed-rate gig apps.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Monopoly Fixed Apps */}
          <div className="p-6 sm:p-8 rounded-3xl bg-rose-50/60 border border-rose-200/80 space-y-4">
            <div className="flex items-center gap-2.5 text-rose-700 font-display font-bold text-base">
              <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>Fixed Price Monopoly Apps (Urban Company)</span>
            </div>
            <ul className="space-y-3 text-xs sm:text-sm text-slate-700">
              <li className="flex items-start gap-2.5">
                <span className="text-rose-600 font-black">✕</span>
                <span>Platform dictates prices with <strong>25% to 40%</strong> commission extracted from workers</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-600 font-black">✕</span>
                <span>Inflexible schedule slots requiring customers to wait 2 to 4 hours</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-600 font-black">✕</span>
                <span>Workers penalized or suspended arbitrarily if they reject unfavorable distant jobs</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-600 font-black">✕</span>
                <span>One-sided customer ratings leave workers vulnerable to false complaints</span>
              </li>
            </ul>
          </div>

          {/* KaamWala Marketplace */}
          <div className="p-6 sm:p-8 rounded-3xl bg-primary-50/60 border border-primary-200/80 space-y-4">
            <div className="flex items-center gap-2.5 text-primary-800 font-display font-bold text-base">
              <CheckCircle2 className="w-5 h-5 text-primary-600 shrink-0" />
              <span>KaamWala Open Marketplace</span>
            </div>
            <ul className="space-y-3 text-xs sm:text-sm text-slate-700">
              <li className="flex items-start gap-2.5">
                <span className="text-primary-600 font-black">✓</span>
                <span><strong>100% worker-set pricing</strong> — workers keep every single rupee they quote with 0% platform cuts</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-primary-600 font-black">✓</span>
                <span><strong>30-minute matching SLA</strong> with live GPS bike arrival tracker and 3-minute radius escalation</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-primary-600 font-black">✓</span>
                <span>Real mini reverse auction negotiation so both sides agree willingly</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-primary-600 font-black">✓</span>
                <span>Voice-first quoting in <strong>Marathi and Hindi</strong> for workers with low digital comfort</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-500 font-medium text-center sm:text-left">
            Ready to experience fair work and fair pay on your doorstep?
          </p>
          <button
            onClick={onStartBooking}
            className="btn-primary text-xs sm:text-sm px-6 py-3 shadow-sm flex items-center gap-2"
          >
            <span>Post a Request Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>

    </div>
  );
};
