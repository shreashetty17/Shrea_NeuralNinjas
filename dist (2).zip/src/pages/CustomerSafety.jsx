import React, { useState } from 'react';
import { 
  ShieldCheck, 
  KeyRound, 
  ShieldAlert, 
  Lock, 
  CheckCircle2, 
  ArrowRight,
  FileCheck,
  AlertTriangle,
  Camera,
  Star
} from 'lucide-react';
import { playAudioCue } from '../data/mockData';

export const CustomerSafety = ({ onOpenSos, onOpenVerifyModal, onOpenEscrowModal }) => {
  const [sirenPlaying, setSirenPlaying] = useState(false);

  const handleTestSiren = () => {
    setSirenPlaying(true);
    playAudioCue('sos');
    setTimeout(() => {
      setSirenPlaying(false);
    }, 2500);
  };

  return (
    <div className="space-y-16 animate-in fade-in">
      
      {/* Page Header */}
      <div className="space-y-4 max-w-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider">
          <span>Trust & Safety</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-display font-bold text-slate-900 tracking-tight">
          Safety isn't a feature. It's the foundation.
        </h1>
        <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
          Every technician is rigorously vetted before entering your home. Every transaction is escrow-protected, and emergency SOS alerts guarantee immediate security.
        </p>
      </div>

      {/* 4-Tier Verification Cards */}
      <div className="space-y-6">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">
            COMPREHENSIVE BACKGROUND ENGINE
          </span>
          <h2 className="text-2xl font-display font-bold text-slate-900 mt-0.5">
            4-Tier Worker Verification Stack
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              1
            </div>
            <h3 className="font-display font-bold text-base text-slate-900">
              Government ID & e-KYC
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Real-time validation against Aadhaar via DigiLocker API. Biometric matching prevents duplicate profiles and identity fraud.
            </p>
            <span className="inline-block text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
              ✓ Verified Identity
            </span>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              2
            </div>
            <h3 className="font-display font-bold text-base text-slate-900">
              Police Criminal Clearance
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Background check conducted with Mumbai Police Special Branch. Zero criminal history required for platform onboarding.
            </p>
            <span className="inline-block text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
              ✓ Clean Criminal Record
            </span>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              3
            </div>
            <h3 className="font-display font-bold text-base text-slate-900">
              NSDC Skill Certification
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              National Skill Development Corporation certified trade evaluation. Hands-on practical testing for pipe pressure and wiring safety.
            </p>
            <span className="inline-block text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
              ✓ Trade Certified
            </span>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              4
            </div>
            <h3 className="font-display font-bold text-base text-slate-900">
              Two-Way Rating Shield
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Continuous performance monitoring. Mutual rating ensures mutual respect. Workers maintaining under 4.6★ are deboarded for training.
            </p>
            <span className="inline-block text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
              ✓ 4.9★ Mumbai Average
            </span>
          </div>

        </div>
      </div>

      {/* Interactive Safety Features: Start OTP, SOS Siren, Escrow-Lite */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Feature 1: Start OTP */}
        <div className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-primary-50 text-primary-700 flex items-center justify-center font-bold">
            <KeyRound className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-display font-bold text-slate-900">
            Photo Check & Start OTP
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            The technician cannot begin service until they enter your unique 4-digit code. This guarantees the exact verified person on your booking arrives at your door.
          </p>
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Your Current Start OTP</span>
            <span className="text-2xl font-mono font-black text-secondary-600">4829</span>
          </div>
        </div>

        {/* Feature 2: SOS Siren Alert */}
        <div className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-display font-bold text-slate-900">
            Emergency SOS Siren
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            One tap immediately sounds a loud deterrent siren locally and transmits live GPS coordinates to Mumbai Police 112 and your trusted contact.
          </p>
          <div className="pt-2">
            <button
              onClick={handleTestSiren}
              className={`w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-sm ${
                sirenPlaying
                  ? 'bg-rose-700 text-white animate-pulse'
                  : 'bg-rose-600 hover:bg-rose-700 text-white'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              <span>{sirenPlaying ? 'Siren Sounding (Testing)...' : 'Test Audible Siren (Sound On)'}</span>
            </button>
          </div>
        </div>

        {/* Feature 3: Escrow-Lite Terms */}
        <div className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-display font-bold text-slate-900">
            Escrow-Lite Protection
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Payment is held in a protected escrow vault and only released after your physical inspection. Before & after photos resolve any disputes within 15 minutes.
          </p>
          <div className="pt-2">
            <button
              onClick={onOpenEscrowModal}
              className="w-full py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs border border-slate-200 transition-colors"
            >
              View Escrow Rules & Terms
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
