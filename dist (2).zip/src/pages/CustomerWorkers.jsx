import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Star, 
  Clock, 
  MapPin, 
  ArrowRight,
  Search,
  CheckCircle2,
  Phone
} from 'lucide-react';
import { WORKERS_DATABASE } from '../data/mockData';

export const CustomerWorkers = ({ onSelectWorkerToBook }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTrade, setFilterTrade] = useState('all');

  const filtered = WORKERS_DATABASE.filter((w) => {
    const matchTrade = filterTrade === 'all' || w.trade === filterTrade;
    const matchSearch = !searchQuery.trim() || 
      w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.locality.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (w.specialty && w.specialty.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchTrade && matchSearch;
  });

  return (
    <div className="space-y-12 animate-in fade-in">
      
      {/* Page Header */}
      <div className="space-y-4 max-w-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary-100 text-secondary-800 text-xs font-bold uppercase tracking-wider">
          <span>Verified Workforce</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-display font-bold text-slate-900 tracking-tight">
          Meet Mumbai's top-rated technicians
        </h1>
        <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
          Every technician is background verified with police clearance, skill certified by NSDC, and rated directly by fellow Mumbai residents.
        </p>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-bolt-sm space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by worker name, trade, or locality (e.g. Bandra, Lokhandwala, Dadar)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:bg-white focus:ring-2 focus:ring-primary-500"
            />
          </div>

          {/* Trade Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto no-scrollbar">
            {[
              { id: 'all', label: 'All' },
              { id: 'plumbing', label: 'Plumbers' },
              { id: 'electrical', label: 'Electricians' },
              { id: 'cleaning', label: 'Maids' },
              { id: 'cooking', label: 'Cooks' },
              { id: 'ac_repair', label: 'AC Tech' },
              { id: 'carpentry', label: 'Carpenters' }
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setFilterTrade(t.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                  filterTrade === t.id
                    ? 'bg-primary-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:text-slate-900 hover:bg-slate-200'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 px-1">
          <span>Showing {filtered.length} verified professionals in Mumbai</span>
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="text-primary-600 font-bold hover:underline">
              Clear search
            </button>
          )}
        </div>
      </div>

      {/* Workers Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((w) => (
          <div
            key={w.id}
            className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-bolt-sm hover:shadow-bolt-md transition-all space-y-5 flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <img
                  src={w.photo}
                  alt={w.name}
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-primary-200 shrink-0 shadow-sm"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-display font-bold text-base text-slate-900 truncate">
                      {w.name}
                    </h3>
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  </div>
                  <p className="text-xs font-semibold text-primary-700 capitalize">
                    {w.tradeLabel || w.trade}
                  </p>
                  <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="truncate">{w.locality}</span>
                  </p>
                </div>
              </div>

              {/* Badges / Stats */}
              <div className="grid grid-cols-3 gap-2 py-3 px-3 bg-slate-50 rounded-2xl border border-slate-100 text-center text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Rating</span>
                  <span className="font-bold text-amber-500 flex items-center justify-center gap-0.5">
                    <Star className="w-3 h-3 fill-amber-400" />
                    <span>{w.rating}</span>
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Jobs</span>
                  <span className="font-bold text-slate-900">{w.jobsCompleted || w.jobsDone || 120}+</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">ETA</span>
                  <span className="font-bold text-emerald-700">{w.etaMins}m</span>
                </div>
              </div>

              {/* Bio & Skills */}
              <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                {w.specialty || w.bio || 'Experienced verified technician with 5+ years of verified on-field experience in Mumbai.'}
              </p>

              <div className="flex flex-wrap gap-1.5">
                {(w.badges || ['Verified Pro', 'Aadhaar Verified']).slice(0, 3).map((badge, idx) => (
                  <span key={idx} className="text-[10px] font-semibold bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full">
                    {badge}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Rate range</span>
                <span className="text-xs font-bold text-slate-900">{w.fairRateRange || `₹${w.hourlyRate || 350}/job`}</span>
              </div>
              <button
                onClick={() => onSelectWorkerToBook(w)}
                className="btn-primary text-xs px-4 py-2"
              >
                <span>Request Bid</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
