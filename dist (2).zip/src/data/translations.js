// KaamWala Multi-Language Localization Engine
// English (en), हिंदी (hi), मराठी (mr)

export const TRANSLATIONS = {
  en: {
    // Brand & Tagline
    appName: 'KaamWala',
    tagline: 'Fair work. Fair pay. On your doorstep.',
    subtitle: 'The marketplace where plumbers, electricians, maids, and cooks set their own prices — and you negotiate directly. Matched in 30 minutes.',
    
    // Navbar
    navHome: 'Home',
    navServices: 'Services',
    navHowItWorks: 'How it works',
    navSafety: 'Safety',
    navWorkers: 'Workers',
    navMyBookings: 'My Bookings',
    navLiveMap: 'Live Map',
    navChat: 'Chat',
    navFindWorker: 'Find a Worker',
    navSwitch: 'Switch',
    navRoleCustomer: 'Customer',
    navRoleWorker: 'Worker',

    // Hero stats
    statWorkers: 'Verified workers',
    statJobs: 'Jobs completed',
    statRating: 'Avg rating',
    badgeFastMatch: 'Worker-set pricing. Real negotiation. Matched in 30 min.',

    // Buttons
    btnFindWorker: 'Find a worker',
    btnExploreServices: 'Explore Services',
    btnBookNow: 'Book Now',
    btnRequestBid: 'Request Bid',
    btnTrackMap: 'Track Live Map',
    btnChatWorker: 'Chat with Worker',
    btnCancel: 'Cancel',
    btnConfirm: 'Confirm',
    btnReleaseEscrow: 'Release Escrow',
    btnTestSos: 'Test SOS Siren',

    // Bookings Page
    bookingsTitle: 'My Bookings',
    bookingsSubtitle: 'Track your active requests, scheduled slots, and completed home services.',
    filterAll: 'All Bookings',
    filterActive: 'Active & En Route',
    filterScheduled: 'Scheduled Slots',
    filterCompleted: 'Completed',
    statusEnRoute: 'En Route (Arriving)',
    statusScheduled: 'Scheduled Slot',
    statusCompleted: 'Work Done & Released',
    startOtpLabel: 'Start OTP',
    otpNotice: 'Share only after technician arrives at your door',

    // Chat
    chatLockedTitle: 'Chat Locked',
    chatLockedDesc: 'Direct messaging unlocks once a worker is booked or when you accept a bid.',
    chatPlaceholder: 'Type a message to the worker...',
    quickReplyGate: 'I am at the building gate',
    quickReplyPart: 'Please bring required spare parts',
    quickReplyFloor: 'Lift is working, please come up',
    btnSend: 'Send',

    // Scheduling & Slots
    slotImmediate: 'Immediate (< 30 min)',
    slotScheduled: 'Schedule Slot for Later',
    selectDate: 'Select Date',
    selectSlot: 'Select Time Slot',
    morningSlot: 'Morning (08:00 AM - 11:00 AM)',
    noonSlot: 'Noon (11:00 AM - 02:00 PM)',
    afternoonSlot: 'Afternoon (02:00 PM - 05:00 PM)',
    eveningSlot: 'Evening (05:00 PM - 08:00 PM)',

    // Auth
    authSignIn: 'Sign In',
    authSignUp: 'Create Account',
    authUploadId: 'Upload Government ID / Address Proof',
    authUploadCert: 'Upload Trade Skill / Police Clearance',
    authUploadRequired: 'Document upload is required to complete registration.',
    authFileSelected: 'File verified & attached:',

    // Worker Portal
    workerProTitle: 'Worker Pro',
    workerTabFeed: 'Job Feed',
    workerTabOrders: 'My Orders',
    workerTabActiveJob: 'Active Job & Map',
    workerTabChat: 'Customer Chat',
    workerTabEarnings: 'Earnings',
    workerTabBadges: 'My Badges',
    workerOnline: 'Online',
    workerOffline: 'Offline',
    workerOrdersTitle: 'My Orders & Doorstep OTP Verification',
    workerOrdersSubtitle: 'Take the 4-digit Start OTP from the customer upon reaching their door to officially confirm and start work.',
    workerEnterOtp: 'Enter Customer 4-Digit Start OTP',
    workerVerifyOtpBtn: 'Verify OTP & Confirm Order Start',
    workerOrderCancelled: 'Order Cancelled by Customer',
    workerCancellationFeeRecv: 'Travel & Fuel Compensation Received',
    workerMarkCompleted: 'Mark Job Completed & Release Escrow',
    workerBadgeTier1Title: 'Tier 1: Government ID / Aadhaar Verified',
    workerBadgeTier2Title: 'Tier 2: Police Criminal Clearance Verified',
    workerUploadGovtIdTitle: 'Government ID Upload (Aadhaar / Voter ID / DL)',
    workerUploadPoliceTitle: 'Police Criminal Clearance Certificate Upload'
  },

  hi: {
    // Brand & Tagline
    appName: 'कामवाला',
    tagline: 'सही काम। सही दाम। आपके द्वार पर।',
    subtitle: 'ऐसा मंच जहाँ प्लंबर, इलेक्ट्रीशियन, बाई और रसोइया खुद अपना दाम तय करते हैं — और आप सीधे बात करते हैं। 30 मिनट में सेवा।',

    // Navbar
    navHome: 'होम',
    navServices: 'सेवाएँ',
    navHowItWorks: 'कैसे काम करता है',
    navSafety: 'सुरक्षा',
    navWorkers: 'कारीगर',
    navMyBookings: 'मेरी बुकिंग्स',
    navLiveMap: 'लाइव मैप',
    navChat: 'चैट',
    navFindWorker: 'कारीगर खोजें',
    navSwitch: 'बदलें',
    navRoleCustomer: 'ग्राहक',
    navRoleWorker: 'कारीगर',

    // Hero stats
    statWorkers: 'सत्यापित कारीगर',
    statJobs: 'पूर्ण किए गए काम',
    statRating: 'औसत रेटिंग',
    badgeFastMatch: 'कारीगर तय करेगा दाम। सीधी बातचीत। 30 मिनट में मिलान।',

    // Buttons
    btnFindWorker: 'कारीगर खोजें',
    btnExploreServices: 'सभी सेवाएँ देखें',
    btnBookNow: 'अभी बुक करें',
    btnRequestBid: 'बोली माँगें',
    btnTrackMap: 'लाइव मैप पर ट्रैक करें',
    btnChatWorker: 'कारीगर से चैट करें',
    btnCancel: 'रद्द करें',
    btnConfirm: 'पुष्टि करें',
    btnReleaseEscrow: 'पेमेंट जारी करें',
    btnTestSos: 'सायरन टेस्ट करें',

    // Bookings Page
    bookingsTitle: 'मेरी बुकिंग्स',
    bookingsSubtitle: 'अपने सक्रिय काम, निर्धारित स्लॉट और पूरे हुए घरेलू कामों को ट्रैक करें।',
    filterAll: 'सभी बुकिंग्स',
    filterActive: 'रास्ते में (सक्रिय)',
    filterScheduled: 'तय समय (स्लॉट)',
    filterCompleted: 'पूर्ण हुआ',
    statusEnRoute: 'कारीगर आ रहा है',
    statusScheduled: 'तय समय स्लॉट',
    statusCompleted: 'काम पूरा हुआ',
    startOtpLabel: 'शुरुआती OTP',
    otpNotice: 'कारीगर के दरवाजे पर पहुँचने के बाद ही बताएं',

    // Chat
    chatLockedTitle: 'चैट लॉक है',
    chatLockedDesc: 'कारीगर बुक होने या बोली स्वीकार करने के बाद ही सीधी चैट खुलेगी।',
    chatPlaceholder: 'कारीगर को संदेश लिखें...',
    quickReplyGate: 'मैं नीचे गेट पर हूँ',
    quickReplyPart: 'कृपया जरूरी सामान साथ लाएँ',
    quickReplyFloor: 'लिफ्ट चालू है, ऊपर आ जाएँ',
    btnSend: 'भेजें',

    // Scheduling & Slots
    slotImmediate: 'तत्काल सेवा (30 मिनट में)',
    slotScheduled: 'बाद के लिए स्लॉट चुनें',
    selectDate: 'तारीख चुनें',
    selectSlot: 'समय स्लॉट चुनें',
    morningSlot: 'सुबह (08:00 AM - 11:00 AM)',
    noonSlot: 'दोपहर (11:00 AM - 02:00 PM)',
    afternoonSlot: 'तीसरे पहर (02:00 PM - 05:00 PM)',
    eveningSlot: 'शाम (05:00 PM - 08:00 PM)',

    // Auth
    authSignIn: 'साइन इन करें',
    authSignUp: 'नया खाता बनाएँ',
    authUploadId: 'सरकारी पहचान पत्र (आधार कार्ड) अपलोड करें',
    authUploadCert: 'हुनर प्रमाण पत्र / पुलिस क्लीयरेंस अपलोड करें',
    authUploadRequired: 'पंजीकरण पूरा करने के लिए दस्तावेज़ अपलोड करना अनिवार्य है।',
    authFileSelected: 'दस्तावेज़ सफलतापूर्वक जुड़ा:',

    // Worker Portal
    workerProTitle: 'कारीगर प्रो',
    workerTabFeed: 'काम फ़ीड',
    workerTabOrders: 'मेरे ऑर्डर्स',
    workerTabActiveJob: 'सक्रिय काम व मैप',
    workerTabChat: 'ग्राहक चैट',
    workerTabEarnings: 'कमाई',
    workerTabBadges: 'मेरे बैज',
    workerOnline: 'ऑनलाइन',
    workerOffline: 'ऑफलाइन',
    workerOrdersTitle: 'मेरे ऑर्डर्स और शुरुआती OTP सत्यापन',
    workerOrdersSubtitle: 'ग्राहक के दरवाजे पर पहुँचकर 4 अंकों का शुरुआती OTP लेकर दर्ज करें और काम की आधिकारिक शुरुआत करें।',
    workerEnterOtp: 'ग्राहक का 4 अंकों का OTP दर्ज करें',
    workerVerifyOtpBtn: 'OTP सत्यापित करें और काम शुरू करें',
    workerOrderCancelled: 'ग्राहक द्वारा ऑर्डर रद्द किया गया',
    workerCancellationFeeRecv: 'यात्रा और पेट्रोल भत्ता प्राप्त (+₹50 जमा)',
    workerMarkCompleted: 'काम पूरा चिह्नित करें और पेमेंट प्राप्त करें',
    workerBadgeTier1Title: 'स्तर 1: सरकारी पहचान पत्र (आधार) सत्यापित',
    workerBadgeTier2Title: 'स्तर 2: पुलिस आपराधिक अनापत्ति (क्लियरेंस) सत्यापित',
    workerUploadGovtIdTitle: 'सरकारी पहचान पत्र अपलोड (आधार / वोटर कार्ड)',
    workerUploadPoliceTitle: 'पुलिस क्लीयरेंस प्रमाण पत्र अपलोड'
  },

  mr: {
    // Brand & Tagline
    appName: 'कामवाला',
    tagline: 'योग्य काम. योग्य मोबदला. आपल्या दारी.',
    subtitle: 'प्लंबर, इलेक्ट्रिशियन, मोलकरीण आणि स्वयंपाकी स्वतःचे दर ठरवतात — आणि तुम्ही थेट बोलणी करता. 30 मिनिटांत कारागीर हजर.',

    // Navbar
    navHome: 'मुख्यपृष्ठ',
    navServices: 'सेवा',
    navHowItWorks: 'कसे चालते',
    navSafety: 'सुरक्षितता',
    navWorkers: 'कारागीर',
    navMyBookings: 'माझी बुकिंग',
    navLiveMap: 'थेट नकाशा',
    navChat: 'संभाषण (चॅट)',
    navFindWorker: 'कारागीर शोधा',
    navSwitch: 'बदला',
    navRoleCustomer: 'ग्राहक',
    navRoleWorker: 'कारागीर',

    // Hero stats
    statWorkers: 'पडताळलेले कारागीर',
    statJobs: 'पूर्ण झालेली कामे',
    statRating: 'सरासरी रेटिंग',
    badgeFastMatch: 'कारागीर ठरवणार दर. थेट बोलणी. 30 मिनिटांत काम सुरू.',

    // Buttons
    btnFindWorker: 'कारागीर शोधा',
    btnExploreServices: 'सर्व सेवा पहा',
    btnBookNow: 'आता बुक करा',
    btnRequestBid: 'दर मागवा',
    btnTrackMap: 'थेट नकाशावर ट्रॅक करा',
    btnChatWorker: 'कारागिराशी बोला',
    btnCancel: 'रद्द करा',
    btnConfirm: 'नक्की करा',
    btnReleaseEscrow: 'पैसे जमा करा',
    btnTestSos: 'सायरन तपासा',

    // Bookings Page
    bookingsTitle: 'माझी बुकिंग',
    bookingsSubtitle: 'आपली चालू कामे, ठरवलेले स्लॉट आणि पूर्ण झालेल्या सेवांची माहिती.',
    filterAll: 'सर्व बुकिंग',
    filterActive: 'रस्त्यात आहे (चालू)',
    filterScheduled: 'ठरवलेला स्लॉट',
    filterCompleted: 'पूर्ण झालेले काम',
    statusEnRoute: 'कारागीर येत आहे',
    statusScheduled: 'ठरवलेला वेळ',
    statusCompleted: 'काम पूर्ण झाले',
    startOtpLabel: 'सुरुवातीचा OTP',
    otpNotice: 'कारागीर घरी आल्यावरच हा कोड सांगा',

    // Chat
    chatLockedTitle: 'चॅट बंद आहे',
    chatLockedDesc: 'कारागीर बुक केल्यानंतर किंवा कोट स्वीकारल्यानंतरच थेट संभाषण सुरू होईल.',
    chatPlaceholder: 'कारागिराला मेसेज पाठवा...',
    quickReplyGate: 'मी खाली गेटवर आहे',
    quickReplyPart: 'कृपया लागणारे सुटे भाग सोबत आणा',
    quickReplyFloor: 'लिफ्ट चालू आहे, वर या',
    btnSend: 'पाठवा',

    // Scheduling & Slots
    slotImmediate: 'तातडीने (30 मिनिटांत)',
    slotScheduled: 'वेळेनुसार स्लॉट बुक करा',
    selectDate: 'तारीख निवडा',
    selectSlot: 'वेळेचा स्लॉट निवडा',
    morningSlot: 'सकाळी (08:00 AM - 11:00 AM)',
    noonSlot: 'दुपारी (11:00 AM - 02:00 PM)',
    afternoonSlot: 'दुपारनंतर (02:00 PM - 05:00 PM)',
    eveningSlot: 'संध्याकाळी (05:00 PM - 08:00 PM)',

    // Auth
    authSignIn: 'साइन इन',
    authSignUp: 'नवीन खाते उघडा',
    authUploadId: 'शासकीय ओळखपत्र (आधार कार्ड) अपलोड करा',
    authUploadCert: 'कौशल्य प्रमाणपत्र / पोलीस पडताळणी पत्र अपलोड करा',
    authUploadRequired: 'नोंदणी पूर्ण करण्यासाठी कागदपत्र अपलोड करणे बंधनकारक आहे.',
    authFileSelected: 'दस्तऐवज जोडला गेला:',

    // Worker Portal
    workerProTitle: 'कारागीर प्रो',
    workerTabFeed: 'कामाचे फीड',
    workerTabOrders: 'माझे ऑर्डर्स',
    workerTabActiveJob: 'सक्रिय काम व नकाशा',
    workerTabChat: 'ग्राहक चॅट',
    workerTabEarnings: 'कमाई',
    workerTabBadges: 'माझे बॅज',
    workerOnline: 'ऑनलाइन',
    workerOffline: 'ऑफलाइन',
    workerOrdersTitle: 'माझे ऑर्डर्स आणि थेट OTP पडताळणी',
    workerOrdersSubtitle: 'ग्राहकाच्या घरी पोहोचल्यावर 4-अंकी सुरुवातीचा OTP घ्या आणि काम सुरू करा.',
    workerEnterOtp: 'ग्राहकाचा 4-अंकी OTP टाका',
    workerVerifyOtpBtn: 'OTP तपासा आणि काम नक्की करा',
    workerOrderCancelled: 'ग्राहकाने ऑर्डर रद्द केली',
    workerCancellationFeeRecv: 'प्रवास व पेट्रोल खर्च जमा (+₹50 प्राप्त)',
    workerMarkCompleted: 'काम पूर्ण झाले व पैसे मिळवा',
    workerBadgeTier1Title: 'टप्पा 1: शासकीय ओळखपत्र (आधार) पडताळणी पूर्ण',
    workerBadgeTier2Title: 'टप्पा 2: पोलीस चारित्र्य पडताळणी पूर्ण',
    workerUploadGovtIdTitle: 'शासकीय ओळखपत्र अपलोड करा (आधार / मतदार ओळखपत्र)',
    workerUploadPoliceTitle: 'पोलीस पडताळणी प्रमाणपत्र अपलोड करा'
  }
};
