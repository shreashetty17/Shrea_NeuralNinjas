@echo off
title KaamSetu - Hyperlocal Blue-Collar Services Platform
cd /d "%~dp0"

echo ===============================================================
echo     KAAMSETU (कामसेतु) - Hyperlocal Blue-Collar Platform
echo     Starting application for presentation on any computer...
echo ===============================================================

where npm >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo [OK] Node.js detected. Launching high-performance server on 0.0.0.0:5173...
    start http://localhost:5173/
    npm run dev -- --host 0.0.0.0 --port 5173
    goto end
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo [OK] Python detected. Serving production dist folder on port 5173...
    start http://localhost:5173/
    python -m http.server 5173 --directory dist
    goto end
)

echo [OK] Opening standalone production build directly in default browser...
start "" "%~dp0dist\index.html"

:end
