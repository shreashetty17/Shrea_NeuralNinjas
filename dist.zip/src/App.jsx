import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Clock, 
  MapPin, 
  Award, 
  KeyRound, 
  HeartHandshake, 
  Presentation, 
  User, 
  Briefcase,
  ChevronRight,
  Sparkles,
  Zap
} from 'lucide-react';

import { Navbar } from './components/Navbar';
import { AIProblemDiagnostics } from './components/AIProblemDiagnostics';
import { LiveBiddingAuction } from './components/LiveBiddingAuction';
import { LiveMapTracker } from './components/LiveMapTracker';
import { WorkerAppView } from './components/WorkerAppView';
import { TrustSafetyModal } from './components/TrustSafetyModal';
import { Slide5Comparison } from './components/Slide5Comparison';
import { GuidedDemoTour } from './components/GuidedDemoTour';
import { RecurringBookings } from './components/RecurringBookings';
import { WORKERS_DATABASE, SERVICE_CATEGORIES, playAudioCue } from './data/mockData';

export function App() {
  const [activeTab, setActiveTab] = useState('customer'); // 'customer' | 'worker' | 'comparison' | 'recurring'
  const [customerSubTab, setCustomerSubTab] = useState('bidding'); // 'bidding' | 'map' | 'recurring'
  const [language, setLanguage] = useState('en'); // 'en' | 'hi' | 'mr'
  const [selectedLocation, setSelectedLocation] = useState('Lokhandwala, Andheri West');
  
  const [activeJob, setActiveJob] = useState({
    category: SERVICE_CATEGORIES[0], // Plumbing
    description: 'Master bathroom diverter cartridge leaking continuously. Water spilling into vanity.',
    budget: 350,
    isBundled: false,
    urgency: 'immediate',
    photo: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=600&q=80',
    aiDiagnosticResult: {
      detectedIssue: 'Worn Brass Ceramic Cartridge Leak & P-Trap Pressure',
      severity: 'Medium-High',
      fairRange: '₹280 - ₹450',
      typicalSparesCost: '₹80 - ₹120',
      estimatedFixTime: '25-35 minutes'
    },
    createdAt: '1:45 PM'
  });

  const [activeBooking, setActiveBooking] = useState(null);
  const [selectedWorker, setSelectedWorker] = useState(WORKERS_DATABASE[0]);

  const [modalState, setModalState] = useState({
    isOpen: false,
    mode: 'sos'
  });

  const [isDemoTourOpen, setIsDemoTourOpen] = useState(false);

  const handleJobCreated = (newJob) => {
    setActiveJob(newJob);
    setActiveBooking(null);
    setCustomerSubTab('bidding');
    playAudioCue('bid_received');
  };

  const handleAcceptQuote = (bid) => {
    setActiveBooking({
      job: activeJob,
      quote: bid,
      acceptedAt: new Date().toLocaleTimeString(),
      escrowLocked: true
    });
    setCustomerSubTab('map');
    playAudioCue('match_success');
  };

  const handleConfirmCompletion = (booking) => {
    setModalState({
      isOpen: true,
      mode: 'two_way_rating'
    });
  };

  const handleDemoStepChange = (tab, stepIndex) => {
    setActiveTab(tab);
    if (tab === 'customer') {
      if (stepIndex === 1) setCustomerSubTab('bidding');
      if (stepIndex === 2) setCustomerSubTab('map');
      if (stepIndex === 4) {
        setModalState({ isOpen: true, mode: 'verify_flow' });
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F6F2] text-stone-900 flex flex-col font-sans selection:bg-brand-500 selection:text-white">
      
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        language={language}
        setLanguage={setLanguage}
        selectedLocation={selectedLocation}
        setSelectedLocation={setSelectedLocation}
        onOpenSos={() => setModalState({ isOpen: true, mode: 'sos' })}
        onStartDemoTour={() => setIsDemoTourOpen(true)}
        activeJob={activeJob}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        
        {/* CUSTOMER VIEW */}
        {activeTab === 'customer' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            
            {/* Clean, Non-Cluttered Hero Section */}
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between pb-3 border-b border-[#E8E3DA] gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-brand-50 text-brand-600 border border-brand-200">
                    Dignified Labor Marketplace
                  </span>
                  <span className="text-xs font-semibold text-stone-500">
                    Reverse Bidding • No Fixed Monopoly Markup
                  </span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1 tracking-tight">
                  Hyperlocal On-Demand Services in Mumbai
                </h1>
                <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
                  Set your budget, let nearby verified workers bid openly, and match within ~18 to 30 minutes.
                </p>
              </div>

              {/* Sub-tab Pill Navigation */}
              <div className="flex items-center p-1 rounded-2xl bg-white border border-[#E8E3DA] text-xs font-extrabold shadow-warm-sm">
                <button
                  onClick={() => setCustomerSubTab('bidding')}
                  className={`px-4 py-2 rounded-xl transition-all ${
                    customerSubTab === 'bidding'
                      ? 'bg-charcoal-900 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  ⚡ Reverse Auction
                </button>
                <button
                  onClick={() => setCustomerSubTab('map')}
                  className={`px-4 py-2 rounded-xl transition-all ${
                    customerSubTab === 'map'
                      ? 'bg-charcoal-900 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  🗺️ 30+ Worker Map
                </button>
                <button
                  onClick={() => setCustomerSubTab('recurring')}
                  className={`px-4 py-2 rounded-xl transition-all ${
                    customerSubTab === 'recurring'
                      ? 'bg-charcoal-900 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  🔄 Maid/Cook Plans
                </button>
              </div>
            </div>

            {/* Trust Highlights Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div
                onClick={() => setModalState({ isOpen: true, mode: 'verify_flow' })}
                className="p-3.5 bg-white rounded-2xl border border-[#E8E3DA] shadow-warm-sm hover:border-brand-500 cursor-pointer transition-all flex items-center gap-3"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 border border-emerald-200">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-900">4-Tier Verified</div>
                  <div className="text-[10px] text-stone-500">Aadhaar + Police + NSDC</div>
                </div>
              </div>

              <div
                onClick={() => setModalState({ isOpen: true, mode: 'escrow_details' })}
                className="p-3.5 bg-white rounded-2xl border border-[#E8E3DA] shadow-warm-sm hover:border-brand-500 cursor-pointer transition-all flex items-center gap-3"
              >
                <div className="w-9 h-9 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center shrink-0 border border-brand-200">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-900">Escrow-Lite Safe</div>
                  <div className="text-[10px] text-stone-500">Released after inspection</div>
                </div>
              </div>

              <div
                onClick={() => setCustomerSubTab('map')}
                className="p-3.5 bg-white rounded-2xl border border-[#E8E3DA] shadow-warm-sm hover:border-brand-500 cursor-pointer transition-all flex items-center gap-3"
              >
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center shrink-0 border border-stone-200">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-900">&lt; 30-Min Promise</div>
                  <div className="text-[10px] text-stone-500">3-min auto radius widen</div>
                </div>
              </div>

              <div
                onClick={() => setModalState({ isOpen: true, mode: 'two_way_rating' })}
                className="p-3.5 bg-white rounded-2xl border border-[#E8E3DA] shadow-warm-sm hover:border-brand-500 cursor-pointer transition-all flex items-center gap-3"
              >
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center shrink-0 border border-stone-200">
                  <HeartHandshake className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-900">Two-Way Rating</div>
                  <div className="text-[10px] text-stone-500">Mutual respect shield</div>
                </div>
              </div>
            </div>

            {/* TAB 1: BIDDING AUCTION & JOB POST */}
            {customerSubTab === 'bidding' && (
              <div className="space-y-6">
                {activeJob ? (
                  <LiveBiddingAuction
                    job={activeJob}
                    onAcceptQuote={handleAcceptQuote}
                    onCancelJob={() => setActiveJob(null)}
                    onViewWorkerOnMap={(worker) => {
                      setSelectedWorker(worker);
                      setCustomerSubTab('map');
                    }}
                  />
                ) : (
                  <AIProblemDiagnostics
                    onJobCreated={handleJobCreated}
                    language={language}
                  />
                )}

                {activeJob && (
                  <div className="text-center pt-2">
                    <button
                      onClick={() => setActiveJob(null)}
                      className="text-xs font-bold text-brand-600 hover:text-brand-700 underline"
                    >
                      + Post a Different Job or Change Trade Category
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: LIVE MAP */}
            {customerSubTab === 'map' && (
              <LiveMapTracker
                activeBooking={activeBooking}
                onConfirmCompletion={handleConfirmCompletion}
                onOpenSos={() => setModalState({ isOpen: true, mode: 'sos' })}
                selectedWorker={selectedWorker}
                onSelectWorker={setSelectedWorker}
              />
            )}

            {/* TAB 3: RECURRING SUBSCRIPTIONS */}
            {customerSubTab === 'recurring' && (
              <RecurringBookings />
            )}

          </div>
        )}

        {/* WORKER VIEW (Ustaad Partner Mode) */}
        {activeTab === 'worker' && (
          <WorkerAppView
            currentWorker={selectedWorker || WORKERS_DATABASE[0]}
            language={language}
            setLanguage={setLanguage}
          />
        )}

        {/* SLIDE 5 COMPARISON MATRIX */}
        {activeTab === 'comparison' && (
          <Slide5Comparison />
        )}

      </main>

      {/* Trust & Safety Modal */}
      <TrustSafetyModal
        isOpen={modalState.isOpen}
        onClose={() => setModalState({ ...modalState, isOpen: false })}
        mode={modalState.mode}
        activeWorker={activeBooking?.quote?.worker || selectedWorker}
      />

      {/* 2-Min Demo Tour */}
      <GuidedDemoTour
        isOpen={isDemoTourOpen}
        onClose={() => setIsDemoTourOpen(false)}
        onStepChange={handleDemoStepChange}
      />

      {/* Footer */}
      <footer className="mt-16 bg-white border-t border-[#E8E3DA] py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div className="flex items-center gap-2">
            <span className="font-black text-slate-900">KaamSetu (कामसेतु)</span>
            <span>•</span>
            <span>Empowering 30+ Mumbai Technicians with Dignified Living & Fair Bidding</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setModalState({ isOpen: true, mode: 'escrow_details' })}
              className="hover:text-stone-900 transition-colors font-semibold"
            >
              Escrow Rules
            </button>
            <button
              onClick={() => setModalState({ isOpen: true, mode: 'verify_flow' })}
              className="hover:text-stone-900 transition-colors font-semibold"
            >
              4-Tier Badges
            </button>
            <button
              onClick={() => setActiveTab('comparison')}
              className="text-brand-600 font-extrabold hover:text-brand-700"
            >
              Slide 5 Matrix
            </button>
          </div>
        </div>
      </footer>

    </div>
  );
}
export default App;
