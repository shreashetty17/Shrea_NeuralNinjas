import React, { useState } from 'react';
import { Logo } from './Logo';
import { 
  MapPin, 
  ShieldAlert, 
  Globe, 
  User, 
  Briefcase, 
  Presentation, 
  PhoneCall,
  Clock,
  Laptop,
  CheckCircle2
} from 'lucide-react';

export const Navbar = ({
  activeTab,
  setActiveTab,
  language,
  setLanguage,
  selectedLocation,
  setSelectedLocation,
  onOpenSos,
  onStartDemoTour,
  activeJob
}) => {
  const [showNetworkInfo, setShowNetworkInfo] = useState(false);

  const locations = [
    'Lokhandwala, Andheri West',
    'Pali Hill, Bandra West',
    'Shivaji Park, Dadar',
    'Hiranandani Gardens, Powai',
    'Cuffe Parade, Colaba',
    'Ghodbunder Road, Thane'
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#F8F6F2]/90 backdrop-blur-md border-b border-[#E8E3DA] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          
          {/* Brand Logo & Hyperlocal Mumbai Area */}
          <div className="flex items-center gap-5">
            <div onClick={() => setActiveTab('customer')}>
              <Logo size="md" />
            </div>

            {/* Hyperlocal Mumbai Location Pill */}
            <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border border-[#E8E3DA] text-xs font-semibold text-stone-700 shadow-warm-sm">
              <MapPin className="w-3.5 h-3.5 text-brand-500 shrink-0" />
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="bg-transparent border-none text-xs font-bold text-stone-900 focus:outline-none cursor-pointer"
              >
                {locations.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Live GPS Lock" />
            </div>
          </div>

          {/* Mode Switcher: Customer App / Worker App / Slide 5 */}
          <nav className="flex items-center p-1 rounded-2xl bg-white border border-[#E8E3DA] shadow-warm-sm">
            <button
              onClick={() => setActiveTab('customer')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                activeTab === 'customer'
                  ? 'bg-charcoal-900 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <User className="w-3.5 h-3.5 text-brand-400" />
              <span>Customer</span>
              {activeJob && (
                <span className="w-2 h-2 rounded-full bg-brand-500 animate-ping" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('worker')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                activeTab === 'worker'
                  ? 'bg-charcoal-900 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5 text-amber-400" />
              <span>Worker App (कारागीर)</span>
            </button>

            <button
              onClick={() => setActiveTab('comparison')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                activeTab === 'comparison'
                  ? 'bg-charcoal-900 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Presentation className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">Slide 5 Matrix</span>
              <span className="sm:hidden">Matrix</span>
            </button>
          </nav>

          {/* Right Actions: Any Computer Pill, Language, SOS & Demo */}
          <div className="flex items-center gap-2.5">
            {/* Any Computer Network Access Pill */}
            <div className="relative">
              <button
                onClick={() => setShowNetworkInfo(!showNetworkInfo)}
                className="hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white border border-[#E8E3DA] text-[11px] font-bold text-stone-700 hover:border-brand-500 transition-colors shadow-warm-sm"
                title="View network URL to open on other laptops/phones"
              >
                <Laptop className="w-3.5 h-3.5 text-brand-500" />
                <span>Open Anywhere</span>
              </button>

              {showNetworkInfo && (
                <div className="absolute right-0 top-11 z-50 w-72 bg-white rounded-2xl border border-stone-200 shadow-warm-xl p-4 space-y-2.5 animate-in fade-in">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-100">
                    <span className="text-xs font-black text-stone-900 flex items-center gap-1.5">
                      <Laptop className="w-4 h-4 text-brand-500" />
                      Open on Any Computer / Phone
                    </span>
                    <button onClick={() => setShowNetworkInfo(false)} className="text-stone-400 hover:text-stone-600 text-xs">✕</button>
                  </div>
                  <div className="text-[11px] text-stone-600 leading-relaxed">
                    Access this live interface across any laptop, iPad, or mobile phone on the same Wi-Fi:
                  </div>
                  <div className="bg-stone-50 p-2.5 rounded-xl border border-stone-200 font-mono text-xs font-bold text-stone-900 select-all">
                    http://192.168.0.101:5173/
                  </div>
                  <div className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Host 0.0.0.0 is active & broadcasted</span>
                  </div>
                </div>
              )}
            </div>

            {/* Language Switcher */}
            <div className="flex items-center bg-white rounded-xl p-0.5 text-xs font-bold border border-[#E8E3DA] shadow-warm-sm">
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 rounded-lg transition-colors ${
                  language === 'en' ? 'bg-charcoal-900 text-white' : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('hi')}
                className={`px-2 py-1 rounded-lg font-devanagari transition-colors ${
                  language === 'hi' ? 'bg-brand-500 text-white' : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                हिंदी
              </button>
              <button
                onClick={() => setLanguage('mr')}
                className={`px-2 py-1 rounded-lg font-devanagari transition-colors ${
                  language === 'mr' ? 'bg-brand-500 text-white' : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                मराठी
              </button>
            </div>

            {/* 2-Min Demo Walkthrough Guide Button */}
            <button
              onClick={onStartDemoTour}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-black bg-white border border-[#E8E3DA] text-stone-800 hover:border-brand-500 shadow-warm-sm transition-all"
            >
              <Clock className="w-3.5 h-3.5 text-brand-500" />
              <span>2-Min Demo</span>
            </button>

            {/* Emergency SOS Button */}
            <button
              onClick={onOpenSos}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-black bg-red-600 text-white hover:bg-red-700 shadow-warm-sm active:scale-95 transition-all"
              title="Emergency SOS Alert & Police Dispatch"
            >
              <ShieldAlert className="w-4 h-4" />
              <span className="tracking-wider">SOS</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
