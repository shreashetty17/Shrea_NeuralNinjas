import React from 'react';

export const Logo = ({ size = 'md', light = false }) => {
  const isSmall = size === 'sm';
  const isLarge = size === 'lg';

  const iconDim = isSmall ? 'w-8 h-8' : isLarge ? 'w-12 h-12' : 'w-10 h-10';
  const textClass = isSmall ? 'text-lg' : isLarge ? 'text-2xl sm:text-3xl' : 'text-xl';
  const subTextClass = isSmall ? 'text-[9px]' : isLarge ? 'text-xs' : 'text-[11px]';

  return (
    <div className="flex items-center gap-3 select-none cursor-pointer group">
      {/* Refined Geometric Architectural Icon */}
      <div className={`relative ${iconDim} rounded-2xl bg-charcoal-900 border border-charcoal-800 flex items-center justify-center shadow-warm-md group-hover:scale-[1.03] transition-transform`}>
        <svg viewBox="0 0 36 36" className="w-5 h-5 fill-none" stroke="currentColor">
          {/* Saffron Arch Bridge */}
          <path
            d="M 5 25 C 10 11, 26 11, 31 25"
            stroke="#ea580c"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
          {/* Keystone diamond of craftsmanship */}
          <rect x="16" y="7" width="4" height="4" rx="1" transform="rotate(45 18 9)" fill="#f97316" />
          {/* Vertical pillars */}
          <path d="M 12 21 L 12 28 M 24 21 L 24 28" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />
          {/* Horizontal base */}
          <path d="M 6 29 L 30 29" stroke="#cbd5e1" strokeWidth="2.4" strokeLinecap="round" />
        </svg>
        {/* Live green operational indicator */}
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full shadow-xs"></span>
      </div>

      <div className="flex flex-col leading-none">
        <div className={`font-display font-black tracking-tight ${textClass} ${light ? 'text-white' : 'text-slate-900'} flex items-center gap-1.5`}>
          <span>Kaam</span>
          <span className="text-brand-500">Setu</span>
          <span className="text-[10px] font-extrabold uppercase tracking-widest px-1.5 py-0.5 rounded-md bg-stone-100 text-stone-700 border border-stone-200 ml-1 hidden sm:inline-block">
            Marketplace
          </span>
        </div>
        <div className={`${subTextClass} font-devanagari text-stone-500 font-semibold tracking-wide mt-0.5`}>
          कामसेतु • मुंबई लोकल
        </div>
      </div>
    </div>
  );
};
